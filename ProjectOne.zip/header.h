#pragma once 
#ifndef SOURCE_H 
#define SOURCE_H 

class Time {
    //private variable initialiation
private:
    int hour;
    int minute;
    int second;

public:
    Time();//default contructor

    Time(int h, int m, int s) {
        hour = h;
        minute = m;
        second = s;
    }
    //Getter and Setters
    void setHour(int h) { hour = h; } // For write only

    int getHour() { return hour; } // read only

    void setMinute(int m) { minute = m; }

    int getMinute() { return minute; }

    void setSecond(int s) { second = s; }

    int getSecond() { return second; }
};
#endif
